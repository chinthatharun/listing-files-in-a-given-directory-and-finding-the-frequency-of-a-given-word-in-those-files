import os
import pandas as pd
import threading

txt_file_paths = []
xlsx_file_paths = []
results = []
lock = threading.Lock()

# this function list out all files of the given directory
def list_files(directory):
    global txt_file_paths, xlsx_file_paths
    # gives recursively list of all .txt files and .xlsx files in the directory and sub directory
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".txt"):
                with lock:
                    txt_file_paths.append(os.path.join(root, file))
            elif file.endswith(".xlsx"):
                with lock:
                    xlsx_file_paths.append(os.path.join(root, file))

def print_file_paths(file_paths):
    for file_path in file_paths:
        print(file_path)

# This function counts the word in a txt file
def word_count_txtfile(file_path, word):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            read_file = file.read().lower()
            count_word = read_file.count(word.lower())
            result = f"The word '{word}' appeared {count_word} times in {file_path}."
    except FileNotFoundError:
        result = f"Error: File '{file_path}' not found."
    except Exception as e:
        result = f"Error reading file {file_path}: {e}"
    with lock:
        results.append(result)

# This function counts the word in xlsx(excel) file
def count_word_in_excel_file(file_path, word):
    try:
        df = pd.read_excel(file_path)
        df = df.map(lambda x: str(x).lower())
        count_word = df.stack().str.contains(word.lower()).sum()
        result = f"The word '{word}' appeared {count_word} times in {file_path}."
    except FileNotFoundError:
        result = f"Error: File '{file_path}' not found."
    except Exception as e:
        result = f"Error reading file {file_path}: {e}"
    with lock:
        results.append(result)

# word frequency using 20 thread arrangement
def process_files(file_list, processing_function, word, max_threads=20):
    threads = []
    for file in file_list:
        thread = threading.Thread(target=processing_function, args=(file, word))
        thread.start()
        threads.append(thread)

        # the number of active threads does not exceed max_threads
        if len(threads) >= max_threads:
            for t in threads:
                t.join()
            threads = []

    # Joining threads
    for t in threads:
        t.join()

# proceeesing list of files using 10 threads
def print_files_with_threads(file_paths, max_threads=10):
    threads = []
    for file_path in file_paths:
        thread = threading.Thread(target=print_file_paths, args=([file_path],))
        thread.start()
        threads.append(thread)

        # the number of active threads does not exceed max_threads
        if len(threads) >= max_threads:
            for t in threads:
                t.join()
            threads = []

    # Joining threads
    for t in threads:
        t.join()

def main():
    directory = input("Enter the directory:")
    word = input("Enter the word:")

    # Listing the files in the directory
    list_files(directory)

    if not txt_file_paths and not xlsx_file_paths:
        print("No .txt or .xlsx files found in the directory.")
        return

    # Print .txt files paths 
    print("Printing .txt file paths:")
    print_files_with_threads(txt_file_paths, max_threads=10)

    # Print .xlsx files paths 
    print("Printing .xlsx file paths:")
    print_files_with_threads(xlsx_file_paths, max_threads=10)
    
    # printing total files in the given directory path
    total_files_found = len(txt_file_paths) + len(xlsx_file_paths)
    print(f"Total .txt and .xlsx files found: {total_files_found}")

    # Process .txt files (calling the function)
    process_files(txt_file_paths, word_count_txtfile, word, max_threads=20)

    # Process .xlsx files (calling the function)
    process_files(xlsx_file_paths, count_word_in_excel_file, word, max_threads=20)

    
    for result in results:
        print(result)

if __name__ == "__main__":
    main()
